var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};

var appM = angular.module('appMain', ['ngCookies']);

appM.controller('appControl1', function($scope, $http, $cookies) {
   $scope.msj_login = '';
   $scope.user = '';
   $scope.pwd = '';

   validaLogin();

   $scope.login = function(){
        if($scope.user.length >0 && $scope.pwd.length>0){
            $http.post('http://localhost/websistem/server/svrConsultas.php', {op:100, usr:$scope.user, pwd:$scope.pwd}).then(function(vResult){
                //alert(vResult.data);
                if(vResult.data.cod==1){
                    varSistem.user = $scope.user;
                    varSistem.pwd = $scope.pwd;

                    $cookies.put(vEmpresa, JSON.stringify(varSistem), {path:'/'});
                    setTimeout(function () { window.location.replace("main.php");}, 1000);
                    
                }else{
                    //alert(vResult.data);
                    $scope.msj_login = "Error de Usuario o Contraseña";
                }
            });
        }        
   }

function validaLogin(){
    varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
    var vuser = '';
    var vpwd = '';   

    if($cookies.get(vEmpresa)){
            var obj = JSON.parse($cookies.get(vEmpresa));
            
            varSistem.user = obj.user;
            varSistem.pwd = obj.pwd; 
            $http.post('http://localhost/websistem/server/svrConsultas.php', {op:100, usr:varSistem.user, pwd:varSistem.pwd}).then(function(vResult){
                //alert(vResult.data);
                if(vResult.data.cod==1){
                    varSistem.id = vResult.data.id;
                    setTimeout(function () { window.location.replace("main.php");}, 500);                   
                }
            });
    }    
}       

});



function getParams(param) {
    var vars = {};
    window.location.href.replace( location.hash, '' ).replace( 
        /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
        function( m, key, value ) { // callback
            vars[key] = value !== undefined ? value : '';
        }
    );

    if ( param ) {
        return vars[param] ? vars[param] : null;    
    }
    return vars;
}


