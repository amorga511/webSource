// Variable Globales

var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
var vRutaApp = 'localhost/websistem';
var appTitle = 'Your Company';