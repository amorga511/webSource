CREATE DATABASE  IF NOT EXISTS `db_fac` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `db_fac`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: db_fac
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_cai_control`
--

DROP TABLE IF EXISTS `tbl_cai_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cai_control` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa` varchar(45) DEFAULT NULL,
  `rtn` varchar(20) DEFAULT NULL,
  `cai` varchar(60) DEFAULT NULL,
  `rango_desde` varchar(25) DEFAULT NULL,
  `rango_hasta` varchar(25) DEFAULT NULL,
  `fecha_limite` date DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cajas`
--

DROP TABLE IF EXISTS `tbl_cajas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cajas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `num_caja` int(11) NOT NULL,
  `tienda` varchar(20) NOT NULL,
  `monto` decimal(10,0) NOT NULL,
  `fech_apertura` datetime NOT NULL,
  `fech_cierre` datetime NOT NULL,
  `estado_caja` int(11) NOT NULL,
  `cajero` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_cajas_cierre`
--

DROP TABLE IF EXISTS `tbl_cajas_cierre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_cajas_cierre` (
  `id` int(11) NOT NULL,
  `caja` int(11) DEFAULT NULL,
  `cajero` varchar(45) DEFAULT NULL,
  `fech_open` datetime DEFAULT NULL,
  `fech_close` datetime DEFAULT NULL,
  `ingresos_fac` decimal(9,2) DEFAULT NULL,
  `devoluciones` decimal(9,2) DEFAULT NULL,
  `egresos` decimal(9,2) DEFAULT NULL,
  `sobrante_faltante` decimal(9,2) DEFAULT NULL,
  `saldo_inicial` decimal(9,2) DEFAULT NULL,
  `utilidad_neta` decimal(9,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_correlativos`
--

DROP TABLE IF EXISTS `tbl_correlativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_correlativos` (
  `id` varchar(15) NOT NULL,
  `correlativo` int(11) NOT NULL,
  `prefijo` varchar(50) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_factura_detalle`
--

DROP TABLE IF EXISTS `tbl_factura_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_factura_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cod_item` varchar(10) DEFAULT NULL,
  `precio` decimal(9,2) DEFAULT NULL,
  `unidades` decimal(9,2) DEFAULT NULL,
  `factura_id` varchar(60) DEFAULT NULL,
  `detalle` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_facturas`
--

DROP TABLE IF EXISTS `tbl_facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_facturas` (
  `id` varchar(60) NOT NULL,
  `fech_fac` datetime DEFAULT NULL,
  `vendedor` varchar(15) DEFAULT NULL,
  `cliente` varchar(30) DEFAULT NULL,
  `rtn_cliente` varchar(20) DEFAULT NULL,
  `tel_cliente` int(11) DEFAULT NULL,
  `subtotal_exento` decimal(8,2) NOT NULL,
  `subtotal_grabado` decimal(11,2) NOT NULL,
  `descuento` decimal(9,2) DEFAULT NULL,
  `isv` decimal(9,2) DEFAULT NULL,
  `efectivo` decimal(9,2) DEFAULT NULL,
  `tarjeta` decimal(9,2) DEFAULT NULL,
  `total` decimal(9,2) DEFAULT NULL,
  `cajero` varchar(15) DEFAULT NULL,
  `caja` varchar(10) DEFAULT NULL,
  `nota` varchar(45) DEFAULT NULL,
  `cai` varchar(60) DEFAULT NULL,
  `estado` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_personal`
--

DROP TABLE IF EXISTS `tbl_personal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_personal` (
  `id` varchar(20) NOT NULL,
  `nombre_persona` varchar(50) NOT NULL,
  `apellido_persona` varchar(50) NOT NULL,
  `telefono_persona` int(11) NOT NULL,
  `cargo_persona` int(11) NOT NULL,
  `status_persona` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_tiendas`
--

DROP TABLE IF EXISTS `tbl_tiendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_tiendas` (
  `id` varchar(10) NOT NULL,
  `nombre_tienda` varchar(60) NOT NULL,
  `direccion_tienda` varchar(50) NOT NULL,
  `telefono_tienda` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `rtn_tienda` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tbl_trans_caja`
--

DROP TABLE IF EXISTS `tbl_trans_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_trans_caja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `tipo_tran` int(11) NOT NULL,
  `cajero` varchar(15) NOT NULL,
  `caja` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `detalle` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `num` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(20) NOT NULL,
  `password` varchar(30) NOT NULL,
  `id_empleado` varchar(20) NOT NULL,
  `estado` int(11) NOT NULL,
  PRIMARY KEY (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db_fac'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-05-16 21:00:04
