/*var vEmpresa = 'app1';
var varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};*/

var appM = angular.module('appMain', ['ngCookies']);

appM.controller('appControl1', function($scope,$http, $cookies) {
    $scope.btn_menu = false;
    $scope.dvInicio = true;
    $scope.dvCaja = false;
    $scope.dvFacturacion = false;
    $scope.user_name = "";


    $scope.apptitle = appTitle;
    if(window.innerWidth<900){
        $scope.btn_menu = true;
    }

    if(!$cookies.get(vEmpresa)){
        console.log('no login');
        window.location.replace('index.php');
    }else{
        validaLogin();
    }

    $scope.switchMenu = function(vM){
        switch(vM){
            case 1:
                $scope.dvInicio = true;
                $scope.dvCaja = false;
                $scope.dvFacturacion = false;
                $scope.btn_menu =true;
                window.location.replace('main.php');
            break;
            case 2:
                $scope.dvInicio = false;
                $scope.dvStaff = true;
                $scope.dvPersonalOp = false;              
                window.location.replace('views/caja/index.php');
            break;
            case 3:
                $scope.dvInicio = false;
                $scope.dvStaff = true;
                $scope.dvPersonalOp = false;                
                window.location.replace('views/facturacion/index.php');
            break;
            case 99:
                console.log(vEmpresa);
                $cookies.remove(vEmpresa, {path:'/'});
                setTimeout(function(){window.location.replace('index.php');}, 400);
                //$http.post('http://' + vRutaApp + '/server/svrConsultas.php', {op:104}).then(function(vResult){
                  //  window.location.reload();
                //}); 
            break;
            default:
                return;
        }
        if(vM!=99){
            $("#wrapper").toggleClass("toggled");
        }
    }

    $(document).ready(function(){
		//alert('Document Ready');
		$("#btn_menu").click(function(e) {
     		e.preventDefault();
    		$("#wrapper").toggleClass("toggled");
		});
		$("#btn_close_menu").click(function(){
    		$("#wrapper").toggleClass("toggled"); 
 		});
	});

    function validaLogin(){
        varSistem = {"user":'', "pwd":'', "id":'', "name":'', "caja":"-"};
        var vuser = '';
        var vpwd = '';       

        if($cookies.get(vEmpresa)){
            var obj = JSON.parse($cookies.get(vEmpresa));
            
            varSistem.user = obj.user;
            varSistem.pwd = obj.pwd;
            console.log(varSistem.pwd); 

            $http.post('http://' + vRutaApp + '/server/svrConsultas.php', {op:100, usr:varSistem.user, pwd:varSistem.pwd}).then(function(vResult){
                //alert(vResult.data);
                if(vResult.data.cod==0){
                    setTimeout(function () { window.location.replace("index.php");}, 500);                   
                }else{
                    
                    varSistem.id = vResult.data.id;
                    console.log(varSistem.id);
                    $http.post('http://' + vRutaApp + '/server/svrConsultas.php', {op:108, tienda:'TGU001', estado:1, cajero:varSistem.id}).then(function(vResult2){
                        console.log(vResult2.data[0].caja);
                        varSistem.caja = vResult2.data[0].caja;
                            //alert(vResult.data);
                    }); 
                }
            });
        }       
    } 

});
       

function getParams(param) {
    var vars = {};
    window.location.href.replace( location.hash, '' ).replace( 
        /[?&]+([^=&]+)=?([^&]*)?/gi, // regexp
        function( m, key, value ) { // callback
            vars[key] = value !== undefined ? value : '';
        }
    );

    if ( param ) {
        return vars[param] ? vars[param] : null;    
    }
    return vars;
}


